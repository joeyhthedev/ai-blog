import React from 'react'
import styles from "./themeToggle.module.css"

export const ThemeToggle = () => {
  return (
    <div>ThemeToggle</div>
  )
}
