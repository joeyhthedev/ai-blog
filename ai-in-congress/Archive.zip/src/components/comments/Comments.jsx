import React from 'react'
import styles from "./comments.module.css"

const Comments = () => {
  return (
    <div className={styles.container}>Comments Coming Soon!</div>
  )
}

export default Comments