import React from 'react'
import styles from './contributors.module.css'

const Contributors = () => {
  return (
    <div>Contributors coming soon!</div>
  )
}

export default Contributors